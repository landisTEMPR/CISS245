/*********************************************************************
File : PowerStation.cpp
Author: Brysen Landis
*********************************************************************/
/*
void init(PowerStation & powerstation, int x, int y, int energylevel)
{
}
*/

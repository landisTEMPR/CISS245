/************************************************************************
File : Gold.h
Author : Brysen Landis
************************************************************************/

#ifndef GOLD_H
#define GOLD_H

void init_gold(char[10][10], int);

#endif
